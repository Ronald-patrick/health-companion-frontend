import 'package:flutter/material.dart';

class Palette {
  static const Color primary = Color(0xFF2EB086);

  static const Color secondary = Color(0xFFFBF8F1);

  static const Color main = Color(0xFFB8405E);
  

}
