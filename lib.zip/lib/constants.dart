import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF9c27b0);
const kPrimaryLightColor = Color(0xFFF1E6FF);
